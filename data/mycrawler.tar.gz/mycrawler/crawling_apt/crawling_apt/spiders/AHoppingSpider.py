#!/usr/bin/python
#-*- coding: utf-8 -*-

# to execute
# ~/python/mycrawler/crawling_apt$ scrapy crawl ahopper

import scrapy
from listitem import InfoListItem

class AHoppingSpider(scrapy.Spider):
    name = "ahopper"
    allowed_domains = ["apt2you.com"]
    start_urls = [
        "https://www.apt2you.com/",
    ]
    
    def parse(self, response):
        return scrapy.Request(
            url = "https://www.apt2you.com/houseSaleSimpleInfo.do",
            callback = self.parse_notice
        )

    def parse_notice(self, response):

        ## just save the whole HTML page to a local file 
        #page = response.url.split("/")[-2]
        #filename = 'ahopper-%s.html' % page 
        #with open(filename, 'wb') as f :
        #    f.write(response.body)

        rows = response.xpath('//table[@class="tbl_default sortable"]/tbody/tr')

        items = []
        for row in rows:
            item = InfoListItem()
            
            area = row.xpath('td[1]/text()').extract()
            # aptname, constructor, applydates below are the same type
            aptname = row.xpath('td[2]//u/text()').extract()
            constructor = row.xpath('td[3]/text()').extract()
            applydates = row.xpath('td[4]/text()').extract()
            # now area is a list of unicode. type(area) is 'list'

            strarea = area[0].encode("UTF-8")
            # now strarea is a string contains UTF-8 characters
            straptname = aptname[0].encode("UTF-8")
            strconstructor = constructor[0].encode("UTF-8")
            strapplydates = "".join(applydates[0].encode("UTF-8").split())

            tup = (str(strarea), str(straptname), \
                   str(strconstructor), str(strapplydates))
                           
            items.append(tup)

        report = str()
        
        for i in items:
            if (u'서울'.encode("UTF-8") == i[0]) or \
               (u'경기'.encode("UTF-8") == i[0]) or \
               (u'세종'.encode("UTF-8") == i[0]) :
                # u'서울' is a unicode, not a string.
                # so converting it to a UTF-8 character string,
                # then it can be compared

                # for debugging it could be printed on the screen, like below
                print ", ".join(i)
                report = report + ", ".join(i) + "\n"
                
            else :
                pass    

        page = response.url.split("/")[-2]
        filename = 'ahopper-%s.html' % page 
        with open(filename, 'wb') as f :
            f.write(report)
        
