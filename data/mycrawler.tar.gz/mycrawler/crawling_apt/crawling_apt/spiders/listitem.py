import scrapy

class InfoListItem(scrapy.Item):
    Area = scrapy.Field()
    APTName = scrapy.Field()
    Constructor = scrapy.Field()
    ApplyDates = scrapy.Field()
    Notification = scrapy.Field()
    
